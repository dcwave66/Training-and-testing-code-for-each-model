import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.utils.class_weight import compute_class_weight
import numpy as np

# 设置超参数
num_epochs = 150
batch_size = 32
learning_rate = 0.0001
patience = 5
min_delta = 0.001  # 最小改进量

# 数据增强和预处理
transform = transforms.Compose([
    transforms.Resize((224,224)),
    #transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(20),
    #transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 数据集加载
train_dataset = torchvision.datasets.ImageFolder(root='./dataset/30%/train', transform=transform)
val_dataset   = torchvision.datasets.ImageFolder(root='./dataset/30%/val', transform=transform)

train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
val_loader   = torch.utils.data.DataLoader(dataset=val_dataset, batch_size=batch_size, shuffle=False)

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_channels=3, embed_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.projection = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.position_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim))
    def forward(self, x):
        B, _, _, _ = x.shape
        x = self.projection(x)  # [B, embed_dim, H', W']
        x = x.flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        return x, self.position_embed
class Attention(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # [B, num_heads, N, C // num_heads]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
class MLP(nn.Module):
    def __init__(self, in_features, hidden_features, out_features, drop=0.0):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)
    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_dim, qkv_bias=True, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads, qkv_bias, attn_drop, drop)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = MLP(dim, mlp_dim, dim, drop)
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x
class imageTransformer(nn.Module):
    def __init__(self, img_size=224, patch_size=16, num_classes=9, embed_dim=768, depth=10,
                 num_heads=6, mlp_dim=3072, qkv_bias=True, drop_rate=0.1, attn_drop_rate=0.1):
        super().__init__()
        self.patch_embed = PatchEmbedding(img_size, patch_size, 3, embed_dim)
        num_patches = self.patch_embed.num_patches
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_drop = nn.Dropout(p=drop_rate)
        self.blocks = nn.ModuleList([
            TransformerBlock(embed_dim, num_heads, mlp_dim, qkv_bias, drop_rate, attn_drop_rate)
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)
        # self.head = nn.Sequential(
        #     nn.Linear(embed_dim, 512),  # 第一层将特征从 embed_dim 压缩到 512
        #     nn.ReLU(),  # 激活函数
        #     nn.Linear(512, num_classes)  # 第二层将 512 映射到 num_classes
        #)
    def forward(self, x):
        B = x.shape[0]
        x, pos_embed = self.patch_embed(x)
        cls_token = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = x + pos_embed
        x = self.pos_drop(x)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        cls_logits = self.head(x[:, 0])
        return cls_logits
# 实例化模型
model = imageTransformer()
# 选择设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)

# 计算并打印模型参数量
total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"模型总参数量 (Total Parameters): {total_params}")
print(f"可训练参数量 (Trainable Parameters): {trainable_params}")

# 计算类权重
class_weights = compute_class_weight('balanced', classes=np.unique(train_dataset.targets), y=train_dataset.targets)
class_weights = torch.tensor(class_weights, dtype=torch.float).to(device)
# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss(weight=class_weights)
optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
# 使用学习率调度器
#scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)
# 训练和验证
train_losses = []
val_losses = []
best_val_loss = float('inf')
early_stop_counter = 0
# 训练模型
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()  # 清空梯度
        outputs = model(images)  # 前向传播
        loss = criterion(outputs, labels)  # 计算损失
        if torch.isnan(loss):
            print("Loss is NaN, exiting...")
            break
        loss.backward()  # 反向传播
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)  # 梯度裁剪
        optimizer.step()  # 更新参数     model_engine.step()  # 更新模型参数
        running_loss += loss.item()
    # 记录训练损失
    train_losses.append(running_loss / len(train_loader))
    # 验证模型
    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            val_loss += loss.item()
    val_loss /= len(val_loader)
    val_losses.append(val_loss)

    print(f'Epoch [{epoch + 1}/{num_epochs}], '
          f'Training Loss: {train_losses[-1]:.4f}, '
          f'Validation Loss: {val_losses[-1]:.4f}')
    # Early Stopping 检查
    if val_loss < best_val_loss - min_delta:
        best_val_loss = val_loss
        early_stop_counter = 0
        # 保存当前最佳模型
        torch.save(model.state_dict(), './weight/para/ct_image_weights.pth')
        print(f"Validation loss improved, model saved at epoch {epoch + 1}")
    else:
        early_stop_counter += 1
        print(f"No improvement in validation loss for {early_stop_counter} epochs.")

    if early_stop_counter >= patience:
        print(f"Early stopping triggered after {epoch + 1} epochs!")
        break
print('Finished Training')
# 绘制损失曲线
plt.figure(figsize=(12, 6))
# # 设置字体为 Times New Roman
# plt.rcParams['font.family'] = 'Times New Roman'
# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
# 绘制曲线
plt.plot(range(1, len(train_losses) + 1), train_losses, label='训练损失', marker='o', color='skyblue', markersize=6, linewidth=2)
plt.plot(range(1, len(val_losses) + 1), val_losses, label='验证损失', marker='o', color='lightgreen', markersize=6, linewidth=2)
# 设置标题和坐标轴标签
plt.title('训练过程损失曲线图', fontsize=22, fontweight='bold')
plt.xlabel('Epochs', fontsize=20)
plt.ylabel('Loss', fontsize=20)
# 设置刻度大小
plt.xticks(range(1, len(train_losses) + 1),fontsize=20)
plt.yticks(fontsize=20)
# 设置刻度朝内，增强论文风格
plt.tick_params(direction='in', length=6, width=2, labelsize=20)
# 显示图例
plt.legend(fontsize=20)
# 显示网格
plt.grid(True, linestyle='--', linewidth=0.5)
# 紧凑布局，防止标题与标签重叠
plt.tight_layout()
# 保存图片
plt.savefig("./show/para/T_V_Loss_with_Early_Stopping_ct.png", dpi=300, bbox_inches='tight')
# 显示图形
plt.show()
plt.close()

