import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
import seaborn as sns
from sklearn.metrics import ConfusionMatrixDisplay
import numpy as np
import os
from sklearn.manifold import TSNE

def generate_tsne_visualization(features, labels, class_names, save_path):
    """
    使用 t-SNE 对提取的特征进行降维，并生成可视化散点图。
    """
    print(f"\n{'=' * 40}\n开始生成 t-SNE 特征可视化图\n{'=' * 40}")
    print(f"特征维度: {features.shape}")

    # --- 1. 执行t-SNE降维 ---
    print("正在执行t-SNE降维... ")
    tsne = TSNE(
        n_components=2,
        perplexity=min(30.0, features.shape[0] - 1),  # Perplexity不能超过样本数-1
        learning_rate='auto',
        n_iter=1000,
        init='pca',
        random_state=42,  # 固定随机状态以保证结果可复现
        n_jobs=-1  # 使用所有可用的CPU核心
    )
    tsne_results = tsne.fit_transform(features)
    print(f"t-SNE降维完成！降维后维度: {tsne_results.shape}")

    # --- 2. 绘制可视化图 ---
    print("正在绘制t-SNE散点图...")
    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(16, 12))

    # # 设置英文字体
    # plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
    # plt.rcParams['axes.unicode_minus'] = False

    plt.rcParams['font.family'] = 'Times New Roman'

    # 使用 seaborn 的调色板
    num_classes = len(class_names)
    palette = sns.color_palette("deep", num_classes)

    for i in range(num_classes):
        indices = (labels == i)
        # 绘制散点图
        ax.scatter(
            x=tsne_results[indices, 0],
            y=tsne_results[indices, 1],
            color=palette[i],
            label=class_names[i],
            alpha=0.8,
            s=50,
            edgecolors='w',
            linewidth=0.5
        )

    # --- 3. 设置图表样式并保存 ---
    # ax.set_title("The result of t-SNE", fontsize=30, pad=20)
    ax.set_xlabel("t-SNE feature 1", fontsize=26)
    ax.set_ylabel("t-SNE feature 2", fontsize=26)

    legend = ax.legend(loc='best', fontsize=26, markerscale=1.5, title="category", title_fontsize=30)
    legend.get_frame().set_alpha(0.9)

    ax.tick_params(axis='both', which='major', labelsize=24)
    ax.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.tight_layout()

    # 确保保存目录存在
    save_dir = os.path.dirname(save_path)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close(fig)

    print(f"\nt-SNE 可视化图已保存至: {save_path}")
    print(f"{'=' * 40}\n")

# 数据增强和预处理
transform = transforms.Compose([
    transforms.Resize((224, 224)),
    #transforms.RandomHorizontalFlip(),
    #transforms.RandomRotation(20),
    # transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 数据集加载
test_dataset  = torchvision.datasets.ImageFolder(root='./dataset/10dB_10%/test', transform=transform)
test_loader  = torch.utils.data.DataLoader(dataset=test_dataset, batch_size=32, shuffle=False)

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_channels=3, embed_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.projection = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.position_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim))
    def forward(self, x):
        B, _, _, _ = x.shape
        x = self.projection(x)  # [B, embed_dim, H', W']
        x = x.flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        return x, self.position_embed
class Attention(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # [B, num_heads, N, C // num_heads]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
class MLP(nn.Module):
    def __init__(self, in_features, hidden_features, out_features, drop=0.0):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)
    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_dim, qkv_bias=True, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads, qkv_bias, attn_drop, drop)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = MLP(dim, mlp_dim, dim, drop)
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x
class imageTransformer(nn.Module):
    def __init__(self, img_size=224, patch_size=16, num_classes=9, embed_dim=768, depth=10,
                 num_heads=6, mlp_dim=3072, qkv_bias=True, drop_rate=0.1, attn_drop_rate=0.1):
        super().__init__()
        self.patch_embed = PatchEmbedding(img_size, patch_size, 3, embed_dim)
        num_patches = self.patch_embed.num_patches
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.pos_drop = nn.Dropout(p=drop_rate)
        self.blocks = nn.ModuleList([
            TransformerBlock(embed_dim, num_heads, mlp_dim, qkv_bias, drop_rate, attn_drop_rate)
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(embed_dim)
        self.head = nn.Linear(embed_dim, num_classes)
        # self.head = nn.Sequential(
        #     nn.Linear(embed_dim, 512),  # 第一层将特征从 embed_dim 压缩到 512
        #     nn.ReLU(),  # 激活函数
        #     nn.Linear(512, num_classes)  # 第二层将 512 映射到 num_classes
        #)
    def forward(self, x):
        B = x.shape[0]
        x, pos_embed = self.patch_embed(x)
        cls_token = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        x = x + pos_embed
        x = self.pos_drop(x)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        # 提取 [CLS] token作为特征
        features = x[:, 0]
        cls_logits = self.head(features)
        return cls_logits, features
model = imageTransformer()
# 选择设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = model.to(device)
# 加载模型权重
checkpoint = torch.load('./weight/10dB_10%/ct_image_weights.pth',
                            map_location=device)
model.load_state_dict(checkpoint)
# 评估模型
model.eval()
y_true = []
y_pred = []
all_features = []

with torch.no_grad():
    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)

        outputs, features = model(images)

        # outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)
        y_pred.extend(predicted.cpu().numpy()) # 预测标签
        y_true.extend(labels.cpu().numpy())    # 真实标签
        all_features.append(features.cpu().numpy())
# 整合特征
all_features = np.concatenate(all_features, axis=0)
y_true = np.array(y_true)
y_pred = np.array(y_pred)

# 计算评估指标
accuracy = accuracy_score(y_true, y_pred)*100
precision = precision_score(y_true, y_pred, average='weighted')*100
recall = recall_score(y_true, y_pred, average='weighted')*100
f1 = f1_score(y_true, y_pred, average='weighted')

# 输出结果
print(f'Accuracy: {accuracy:.2f}%')
print(f'Precision: {precision:.2f}%')
print(f'Recall: {recall:.2f}%')
print(f'F1 Score: {f1:.4f}')
# plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
# plt.rcParams['axes.unicode_minus'] = False
# 计算混淆矩阵
conf_matrix = confusion_matrix(y_true, y_pred)

# 绘制混淆矩阵
plt.figure(figsize=(10, 8))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=test_dataset.classes,
            yticklabels=test_dataset.classes)
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('Actual')

# plt.savefig("./show/30dB/ct_confusion_matrix.png", dpi=300, bbox_inches='tight')
# plt.show(block=True)  # 阻塞直到图形窗口关闭
# plt.close()  # 关闭当前图形窗口
# 确保保存目录存在
save_dir = "./show/10dB_10%"
if not os.path.exists(save_dir):
    os.makedirs(save_dir)

conf_matrix_path = os.path.join(save_dir, "ct_confusion_matrix.png")
plt.savefig(conf_matrix_path, dpi=300, bbox_inches='tight')
print(f"混淆矩阵已保存至: {conf_matrix_path}")
plt.show(block=True)
plt.close()

#  调用 t-SNE 可视化函数 ---
tsne_save_path = os.path.join(save_dir, 'ct_tsne_visualization.png')
generate_tsne_visualization(all_features, y_true, test_dataset.classes, tsne_save_path)