import torch
import torch.nn as nn
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score, f1_score
import seaborn as sns
from torch.utils.data import Dataset, DataLoader
import os
from PIL import Image
import numpy as np
from sklearn.manifold import TSNE

#数据集加载
class FusionDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.data = []
        # 获取类别名称
        self.class_names = sorted([d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))])
        for label, subdir in enumerate(self.class_names):
            subpath = os.path.join(root_dir, subdir)
            if os.path.isdir(subpath):
                img_dir = os.path.join(subpath, 'image')
                spec_dir = os.path.join(subpath, 'spec')
                for img_name in sorted(os.listdir(img_dir)):
                    spec_name = f"spectrum_{img_name.split('.')[0]}.npy"
                    img_path = os.path.join(img_dir, img_name)
                    spec_path = os.path.join(spec_dir, spec_name)
                    if os.path.exists(img_path) and os.path.exists(spec_path):
                        self.data.append((img_path, spec_path, label))
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        img_path, spec_path, label = self.data[idx]
        image = self.load_image(img_path)
        spectrum = self.load_spectrum(spec_path)
        return image, spectrum, label
    def load_image(self, img_path):
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image
    def load_spectrum(self, spec_path):
        spectrum = np.load(spec_path)  # Shape: (255, 1)
        spectrum = (spectrum - np.min(spectrum)) / (np.max(spectrum) - np.min(spectrum) + 1e-8)  # 归一化到 [0, 1]
        return torch.tensor(spectrum, dtype=torch.float)  # Shape: ( 255, 1)

class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_channels=3, embed_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.projection = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.position_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim))
    def forward(self, x):
        B, _, _, _ = x.shape
        x = self.projection(x)  # [B, embed_dim, H', W']
        x = x.flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        return x, self.position_embed
class Attention(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # [B, num_heads, N, C // num_heads]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
class MLP(nn.Module):
    def __init__(self, in_features, hidden_features, out_features, drop=0.0):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_dim, qkv_bias=True, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads, qkv_bias, attn_drop, drop)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = MLP(dim, mlp_dim, dim, drop)
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x
class imageTransformer(nn.Module):
    def __init__(self, image_size, patch_size, dim, depth,
                 heads, mlp_dim, qkv_bias=True, dropout=0.1,attn_drop=0.1):
        super().__init__()
        self.dim = dim
        self.patch_embed = PatchEmbedding(image_size, patch_size, 3, dim)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos_drop = nn.Dropout(p=dropout)
        self.blocks = nn.ModuleList([
            TransformerBlock(dim, heads, mlp_dim, qkv_bias, dropout,attn_drop)
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Identity()  # 不包含分类头
    def forward(self, x):
        B = x.shape[0]
        # print(f"Input shape: {x.shape}")
        x, pos_embed = self.patch_embed(x)
        # print(f"After patch embed: {x.shape}")  # 打印经过 patch_embed 后的形状
        cls_token = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        # print(f"After concat with cls_token: {x.shape}")  # 拼接后的形状
        x = x + pos_embed
        x = self.pos_drop(x)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        return x[:, 0]  # 返回class token特征  形状: (B,dim)
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    def forward(self, x):
        # 将位置编码加到输入中
        return x + self.pe[:, :x.size(1)].detach()
class SpectrumTransformer(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_heads, num_layers, max_len):
        super(SpectrumTransformer, self).__init__()
        self.hidden_dim = hidden_dim
        # 将 input_dim（特征维度）转换为 hidden_dim
        self.fc = nn.Linear(input_dim, hidden_dim)
        nn.init.xavier_uniform_(self.fc.weight)
        nn.init.zeros_(self.fc.bias)
        # 位置编码层
        self.pos_encoder = PositionalEncoding(hidden_dim, max_len=max_len)
        # Transformer 编码器层
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=num_heads, dim_feedforward = hidden_dim, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
    def forward(self, x):
        # # 如果输入是 4D 张量，则移除多余的维度
        # if x.dim() == 4 and x.shape[1] == 1:
        #     x = x.squeeze(1)  # 形状从 (B, 1, seq_len, input_dim) -> (B, seq_len, input_dim)
        # # 检查输入是否为 3D 张量
        # assert x.dim() == 3, f"Expected input with 3 dimensions (B, seq_len, input_dim), but got {x.shape}"
        # 通过线性层将 input_dim 映射到 hidden_dim
        x = self.fc(x)  # 形状: (B, seq_len, hidden_dim)
        # 添加位置编码
        x = self.pos_encoder(x)
        # 转置为 (seq_len, B, hidden_dim)
        x = x.permute(1, 0, 2)
        # Transformer 编码器
        x = self.encoder(x)  # 输出形状: (seq_len, B, hidden_dim)
        # 返回池化后的值
        x = x.mean(dim=0)  # 形状: (B, hidden_dim)
        return x
class FusionModel(nn.Module):
    def __init__(self, image, transformer, feature_dim, num_classes):
        super(FusionModel, self).__init__()
        self.image = image
        self.transformer = transformer
        # 为了将两个特征融合成统一的维度
        self.fc_img = nn.Linear(image.dim, feature_dim)
        self.fc_spec = nn.Linear(transformer.hidden_dim, feature_dim)
        self.fc = nn.Linear(feature_dim, num_classes)
    def forward(self, img, spec):
        img_features = self.image(img)  # Shape: (B, D_img)
        spec_features = self.transformer(spec)  # Shape: (B, D_spec)
        # 线性投影
        img_features = self.fc_img(img_features)  # Shape: (B, feature_dim)
        spec_features = self.fc_spec(spec_features)  # Shape: (B, feature_dim)
        # 归一化到 [0, 1]
        img_features = (img_features - img_features.min(dim=-1, keepdim=True)[0]) / (
                img_features.max(dim=-1, keepdim=True)[0] - img_features.min(dim=-1, keepdim=True)[0] + 1e-8
        )
        spec_features = (spec_features - spec_features.min(dim=-1, keepdim=True)[0]) / (
                spec_features.max(dim=-1, keepdim=True)[0] - spec_features.min(dim=-1, keepdim=True)[0] + 1e-8
        )
        # 熵值加权融合
        img_entropy = -torch.sum(img_features * torch.log(img_features + 1e-8), dim=-1, keepdim=True)
        spec_entropy = -torch.sum(spec_features * torch.log(spec_features + 1e-8), dim=-1, keepdim=True)
        # weight_img = img_entropy / (img_entropy + spec_entropy + 1e-8)
        # weight_spec = spec_entropy / (img_entropy + spec_entropy + 1e-8)
        weight_img = 1 / (img_entropy + 1e-8)  # 熵值小的特征得到更大的权重
        weight_spec = 1 / (spec_entropy + 1e-8)  # 熵值小的特征得到更大的权重
        # 归一化权重
        weight_sum = weight_img + weight_spec
        weight_img = weight_img / weight_sum
        weight_spec = weight_spec / weight_sum
        fused_features = weight_img * img_features + weight_spec * spec_features

        # 将分类结果和融合特征同时返回
        output = self.fc(fused_features)
        return output, fused_features

        # return self.fc(fused_features)


def generate_tsne_visualization(features, labels, class_names, save_path):
    """
    使用 t-SNE 对提取的特征进行降维，并生成可视化散点图。
    """
    print(f"\n{'=' * 40}\n开始生成 t-SNE 特征可视化图\n{'=' * 40}")
    print(f"特征维度: {features.shape}")

    # --- 1. 执行t-SNE降维 ---
    print("正在执行t-SNE降维... ")
    tsne = TSNE(
        n_components=2,
        perplexity=min(30.0, features.shape[0] - 1),  # Perplexity不能超过样本数-1
        learning_rate='auto',
        n_iter=1000,
        init='pca',
        random_state=42,  # 固定随机状态以保证结果可复现
        n_jobs=-1  # 使用所有可用的CPU核心
    )
    tsne_results = tsne.fit_transform(features)
    print(f"t-SNE降维完成！降维后维度: {tsne_results.shape}")

    # --- 2. 绘制可视化图 ---
    print("正在绘制t-SNE散点图...")
    plt.style.use('seaborn-v0_8-whitegrid')
    fig, ax = plt.subplots(figsize=(16, 12))

    # # 设置英文字体
    # plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS', 'DejaVu Sans']
    # plt.rcParams['axes.unicode_minus'] = False

    plt.rcParams['font.family'] = 'Times New Roman'

    # 使用 seaborn 的调色板
    num_classes = len(class_names)
    palette = sns.color_palette("deep", num_classes)

    for i in range(num_classes):
        indices = (labels == i)
        # 绘制散点图
        ax.scatter(
            x=tsne_results[indices, 0],
            y=tsne_results[indices, 1],
            color=palette[i],
            label=class_names[i],
            alpha=0.8,
            s=50,
            edgecolors='w',
            linewidth=0.5
        )

    # --- 3. 设置图表样式并保存 ---
    # ax.set_title("The result of t-SNE", fontsize=30, pad=20)
    ax.set_xlabel("t-SNE feature 1", fontsize=26)
    ax.set_ylabel("t-SNE feature 2", fontsize=26)

    legend = ax.legend(loc='best', fontsize=26, markerscale=1.5, title="category", title_fontsize=30)
    legend.get_frame().set_alpha(0.9)

    ax.tick_params(axis='both', which='major', labelsize=24)
    ax.grid(True, which='both', linestyle='--', linewidth=0.5)
    plt.tight_layout()

    # 确保保存目录存在
    save_dir = os.path.dirname(save_path)
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close(fig)

    print(f"\nt-SNE 可视化图已保存至: {save_path}")
    print(f"{'=' * 40}\n")


def test_model_and_visualize(model, test_loader, device, class_names):
    model.to(device)
    model.eval()  # 设置为评估模式
    y_true = []
    y_pred = []
    all_features = []  # 用于收集所有批次的特征

    with torch.no_grad():
        for img, spec, labels in test_loader:
            img, spec, labels = img.to(device), spec.to(device), labels.to(device)
            # 前向传播，现在会返回 outputs 和 features
            outputs, features = model(img, spec)
            # 获取预测结果
            _, predicted = torch.max(outputs, 1)

            y_true.extend(labels.cpu().numpy())  # 收集真实标签
            y_pred.extend(predicted.cpu().numpy())  # 收集模型预测标签
            all_features.append(features.cpu().numpy())  # 收集特征

    # 将所有批次的特征和标签连接成一个大的Numpy数组
    all_features = np.concatenate(all_features, axis=0)
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)

    # --- 1. 计算和打印评估指标 ---
    accuracy = accuracy_score(y_true, y_pred) * 100
    precision = precision_score(y_true, y_pred, average='weighted') * 100
    recall = recall_score(y_true, y_pred, average='weighted') * 100
    f1 = f1_score(y_true, y_pred, average='weighted')

    print(f"Accuracy: {accuracy:.2f}%")
    print(f"Precision: {precision:.2f}%")
    print(f"Recall: {recall:.2f}%")
    print(f"F1 Score: {f1:.4f}")

    # --- 2. 绘制和保存混淆矩阵 ---
    conf_matrix = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    sns.heatmap(conf_matrix, annot=True, fmt='d', cmap='Blues', xticklabels=class_names,
                yticklabels=class_names)
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted Labels')
    plt.ylabel('True Labels')

    # 确保保存目录存在
    save_dir = "./show/-10db_10%"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)

    conf_matrix_path = os.path.join(save_dir, "confusion_matrix.png")
    plt.savefig(conf_matrix_path, dpi=300, bbox_inches='tight')
    print(f"混淆矩阵已保存至: {conf_matrix_path}")
    plt.show(block=True)
    plt.close()

    # 调用t-SNE可视化函数 ---
    tsne_save_path = os.path.join(save_dir, 'tsne_visualization.png')
    generate_tsne_visualization(all_features, y_true, class_names, tsne_save_path)

# 主要部分
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    # 加载数据集
    test_dataset = FusionDataset('./dataset/-5db_10%/test', transform=transform)
    test_loader = DataLoader(test_dataset, batch_size=32, shuffle=False)
    # 从数据集中获取类别名称
    class_names = test_dataset.class_names
    num_classes = len(class_names)
    print(f"找到 {num_classes} 个类别: {class_names}")
    # 加载模型
    image_model = imageTransformer(image_size=224, patch_size=16, dim=768, depth=10, heads=6, mlp_dim=3072, dropout=0.1,
                                  attn_drop=0.1)
    Spectrum_model = SpectrumTransformer(input_dim=1, hidden_dim=256, num_heads=8, num_layers=4,max_len=255)
    fusion_model = FusionModel(image_model, Spectrum_model, feature_dim=512, num_classes=9)
    # 加载训练好的模型权重
    model_path = './weight/-5db_10%/best_model.pth'
    fusion_model.load_state_dict(torch.load(model_path,map_location=device))
    # 测试模型
    test_model_and_visualize(fusion_model, test_loader, device,class_names)