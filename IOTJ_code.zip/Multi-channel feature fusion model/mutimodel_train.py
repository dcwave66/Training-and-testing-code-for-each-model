import os
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
import numpy as np
import matplotlib.pyplot as plt
from torch.optim import Adam
from PIL import Image

#数据集加载
class FusionDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.data = []
        for label, subdir in enumerate(sorted(os.listdir(root_dir))):
            subpath = os.path.join(root_dir, subdir)
            if os.path.isdir(subpath):
                img_dir = os.path.join(subpath, 'image')
                spec_dir = os.path.join(subpath, 'spec')
                for img_name in sorted(os.listdir(img_dir)):
                    spec_name = f"spectrum_{img_name.split('.')[0]}.npy"
                    img_path = os.path.join(img_dir, img_name)
                    spec_path = os.path.join(spec_dir, spec_name)
                    if os.path.exists(img_path) and os.path.exists(spec_path):
                        self.data.append((img_path, spec_path, label))
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        img_path, spec_path, label = self.data[idx]
        image = self.load_image(img_path)
        spectrum = self.load_spectrum(spec_path)
        return image, spectrum, label
    def load_image(self, img_path):
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        return image
    def load_spectrum(self, spec_path):
        spectrum = np.load(spec_path)  # Shape: (255, 1)
        spectrum = (spectrum - np.min(spectrum)) / (np.max(spectrum) - np.min(spectrum) + 1e-8)  # 归一化到 [0, 1]
        return torch.tensor(spectrum, dtype=torch.float)  # Shape: ( 255, 1)
#imageTransformer模型
class PatchEmbedding(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_channels=3, embed_dim=768):
        super().__init__()
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.projection = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.position_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, embed_dim))
    def forward(self, x):
        B, _, _, _ = x.shape
        x = self.projection(x)  # [B, embed_dim, H', W']
        x = x.flatten(2).transpose(1, 2)  # [B, num_patches, embed_dim]
        return x, self.position_embed
class Attention(nn.Module):
    def __init__(self, dim, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** -0.5
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # [B, num_heads, N, C // num_heads]
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x
class MLP(nn.Module):
    def __init__(self, in_features, hidden_features, out_features, drop=0.0):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
class TransformerBlock(nn.Module):
    def __init__(self, dim, num_heads, mlp_dim, qkv_bias=True, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = Attention(dim, num_heads, qkv_bias, attn_drop, drop)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = MLP(dim, mlp_dim, dim, drop)
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x
class imageTransformer(nn.Module):
    def __init__(self, image_size, patch_size, dim, depth,
                 heads, mlp_dim, qkv_bias=True, dropout=0.1,attn_drop=0.1):
        super().__init__()
        self.dim = dim
        self.patch_embed = PatchEmbedding(image_size, patch_size, 3, dim)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos_drop = nn.Dropout(p=dropout)
        self.blocks = nn.ModuleList([
            TransformerBlock(dim, heads, mlp_dim, qkv_bias, dropout,attn_drop)
            for _ in range(depth)
        ])
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Identity()  # 不包含分类头
    def forward(self, x):
        B = x.shape[0]
        # print(f"Input shape: {x.shape}")
        x, pos_embed = self.patch_embed(x)
        # print(f"After patch embed: {x.shape}")  # 打印经过 patch_embed 后的形状
        cls_token = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_token, x), dim=1)
        # print(f"After concat with cls_token: {x.shape}")  # 拼接后的形状
        x = x + pos_embed
        x = self.pos_drop(x)
        for block in self.blocks:
            x = block(x)
        x = self.norm(x)
        return x[:, 0]  # 返回class token特征  形状: (B,dim)

class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * -(torch.log(torch.tensor(10000.0)) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)
    def forward(self, x):
        # 将位置编码加到输入中
        return x + self.pe[:, :x.size(1)].detach()
class SpectrumTransformer(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_heads, num_layers, max_len):
        super(SpectrumTransformer, self).__init__()
        self.hidden_dim = hidden_dim
        # 将 input_dim（特征维度）转换为 hidden_dim
        self.fc = nn.Linear(input_dim, hidden_dim)
        nn.init.xavier_uniform_(self.fc.weight)
        nn.init.zeros_(self.fc.bias)
        # 位置编码层
        self.pos_encoder = PositionalEncoding(hidden_dim, max_len=max_len)
        # Transformer 编码器层
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=num_heads, dim_feedforward = hidden_dim, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
    def forward(self, x):
        # # 如果输入是 4D 张量，则移除多余的维度
        # if x.dim() == 4 and x.shape[1] == 1:
        #     x = x.squeeze(1)  # 形状从 (B, 1, seq_len, input_dim) -> (B, seq_len, input_dim)
        # # 检查输入是否为 3D 张量
        # assert x.dim() == 3, f"Expected input with 3 dimensions (B, seq_len, input_dim), but got {x.shape}"
        # 通过线性层将 input_dim 映射到 hidden_dim
        x = self.fc(x)  # 形状: (B, seq_len, hidden_dim)
        # 添加位置编码
        x = self.pos_encoder(x)
        # 转置为 (seq_len, B, hidden_dim)
        x = x.permute(1, 0, 2)
        # Transformer 编码器
        x = self.encoder(x)  # 输出形状: (seq_len, B, hidden_dim)
        # 返回池化后的值
        x = x.mean(dim=0)  # 形状: (B, hidden_dim)
        return x
class FusionModel(nn.Module):
    def __init__(self, image, transformer, feature_dim, num_classes):
        super(FusionModel, self).__init__()
        self.image = image
        self.transformer = transformer
        # 为了将两个特征融合成统一的维度
        self.fc_img = nn.Linear(image.dim, feature_dim)
        self.fc_spec = nn.Linear(transformer.hidden_dim, feature_dim)
        self.fc = nn.Linear(feature_dim, num_classes)
    def forward(self, img, spec):
        img_features = self.image(img)  # Shape: (B, D_img)
        spec_features = self.transformer(spec)  # Shape: (B, D_spec)
        # 线性投影
        img_features = self.fc_img(img_features)  # Shape: (B, feature_dim)
        spec_features = self.fc_spec(spec_features)  # Shape: (B, feature_dim)
        # 归一化到 [0, 1]
        img_features = (img_features - img_features.min(dim=-1, keepdim=True)[0]) / (
                img_features.max(dim=-1, keepdim=True)[0] - img_features.min(dim=-1, keepdim=True)[0] + 1e-8
        )
        spec_features = (spec_features - spec_features.min(dim=-1, keepdim=True)[0]) / (
                spec_features.max(dim=-1, keepdim=True)[0] - spec_features.min(dim=-1, keepdim=True)[0] + 1e-8
        )
        # 熵值加权融合
        img_entropy = -torch.sum(img_features * torch.log(img_features + 1e-8), dim=-1, keepdim=True)
        spec_entropy = -torch.sum(spec_features * torch.log(spec_features + 1e-8), dim=-1, keepdim=True)
        # weight_img = img_entropy / (img_entropy + spec_entropy + 1e-8)
        # weight_spec = spec_entropy / (img_entropy + spec_entropy + 1e-8)
        weight_img = 1 / (img_entropy + 1e-8)  # 熵值小的特征得到更大的权重
        weight_spec = 1 / (spec_entropy + 1e-8)  # 熵值小的特征得到更大的权重
        # 归一化权重
        weight_sum = weight_img + weight_spec
        weight_img = weight_img / weight_sum
        weight_spec = weight_spec / weight_sum
        fused_features = weight_img * img_features + weight_spec * spec_features
        return self.fc(fused_features)
#模型训练验证网络
def train_and_validate(model, train_loader, val_loader, criterion, optimizer, device,
                       epochs=150, patience=5, min_delta=1e-3, save_path="./weight/para/best_model.pth"):
    model.to(device)
    # 验证模型是否在 GPU 上
    print(f"Model is on device: {next(model.parameters()).device}")
    best_val_loss = float('inf')
    best_epoch = 0
    early_stop_counter = 0
    train_losses, val_losses = [], []
    for epoch in range(epochs):
        model.train()
        train_loss = 0.0
        for img, spec, labels in train_loader:
            img, spec, labels = img.to(device), spec.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(img, spec)
            loss = criterion(outputs, labels)
            # 检查 NaN 损失
            if torch.isnan(loss):
                print("Loss is NaN, stopping training.")
                return
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)  # 梯度裁剪
            optimizer.step()
            train_loss += loss.item() * img.size(0)
        train_loss /= len(train_loader.dataset)
        train_losses.append(train_loss)
        # 验证模型
        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for img, spec, labels in val_loader:
                img, spec, labels = img.to(device), spec.to(device), labels.to(device)
                outputs = model(img, spec)
                loss = criterion(outputs, labels)
                val_loss += loss.item() * img.size(0)
        val_loss /= len(val_loader.dataset)
        val_losses.append(val_loss)
        print(f"Epoch [{epoch + 1}/{epochs}] "
              f"Train Loss: {train_loss:.4f} | Val Loss: {val_loss:.4f}")
        # 检查是否是最优模型
        if val_loss < best_val_loss - min_delta:
            best_val_loss = val_loss
            best_epoch = epoch + 1
            early_stop_counter = 0
            torch.save(model.state_dict(), save_path)
            print(f"Validation loss improved to {best_val_loss:.4f}, model saved at epoch {best_epoch}.")
        else:
            early_stop_counter += 1
            print(f"No significant improvement in validation loss for {early_stop_counter} epochs.")
        # 检查早停
        if early_stop_counter >= patience:
            print(f"Early stopping triggered after {epoch + 1} epochs.")
            break
    print(f"Training finished. Best Validation Loss: {best_val_loss:.4f} at epoch {best_epoch}.")
    # 训练完毕后手动保存
    np.save("./show/para/train_losses.npy", np.array(train_losses))
    np.save("./show/para/val_losses.npy", np.array(val_losses))
    print("Loss data saved successfully!")
    # 绘制损失曲线
    plt.figure(figsize=(12, 6))
    # 设置字体为 Times New Roman
    plt.rcParams['font.family'] = 'Times New Roman'
    # 绘制曲线
    plt.plot(range(1, len(train_losses) + 1), train_losses, label='Training Loss', marker='o', color='skyblue',
             markersize=6, linewidth=2)
    plt.plot(range(1, len(val_losses) + 1), val_losses, label='Validation Loss', marker='o', color='lightgreen',
             markersize=6, linewidth=2)
    # 设置标题和坐标轴标签
    plt.title('Training and Validation Loss with Early Stopping', fontsize=22, fontweight='bold')
    plt.xlabel('Epochs', fontsize=20)
    plt.ylabel('Loss', fontsize=20)
    # 设置刻度大小
    plt.xticks(range(1, len(train_losses) + 1), fontsize=12)
    plt.yticks(fontsize=18)
    # 设置刻度朝内，增强论文风格
    plt.tick_params(direction='in', length=6, width=2, labelsize=18)
    # 显示图例
    plt.legend(fontsize=18)
    # 显示网格
    plt.grid(True, linestyle='--', linewidth=0.5)
    # 紧凑布局，防止标题与标签重叠
    plt.tight_layout()
    # 保存图片
    plt.savefig("./show/para/T_V_Loss_with_Early_Stopping.png", dpi=600, bbox_inches='tight')
    # 显示图形
    plt.show()
    plt.close()

# 参数和训练
if __name__ == "__main__":
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    #数据集加载
    train_dataset = FusionDataset('./dataset/-10db_10%/train', transform=transform)
    val_dataset = FusionDataset('./dataset/-10db_10%/val', transform=transform)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=32, shuffle=False)
    #模型实例化
    image_model = imageTransformer(image_size=224, patch_size=16, dim=768, depth=10, heads=6, mlp_dim=3072, dropout=0.1,
                                  attn_drop=0.1)
    Spectrum_model = SpectrumTransformer(input_dim=1, hidden_dim=256, num_heads=8, num_layers=4,max_len=255)
    fusion_model = FusionModel(image_model, Spectrum_model, feature_dim=512, num_classes=9)

    # 计算并打印模型参数量
    total_params = sum(p.numel() for p in fusion_model.parameters())
    trainable_params = sum(p.numel() for p in fusion_model.parameters() if p.requires_grad)
    print(f"模型总参数量 (Total Parameters): {total_params}")
    print(f"可训练参数量 (Trainable Parameters): {trainable_params}")

    criterion = nn.CrossEntropyLoss()
    optimizer = Adam(fusion_model.parameters(), lr=1e-4,weight_decay=1e-5)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_and_validate(fusion_model, train_loader, val_loader, criterion, optimizer, device)
