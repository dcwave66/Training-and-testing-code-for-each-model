import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
from sklearn.utils.class_weight import compute_class_weight
import numpy as np
import timm

# 设置超参数
num_epochs = 200
batch_size = 32
patience = 6
min_delta = 0.001  # 最小改进量

# 数据增强和预处理
transform = transforms.Compose([
    transforms.Resize((299,299)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

# 数据集加载
train_dataset = torchvision.datasets.ImageFolder(root='./dataset/20%/train', transform=transform)
val_dataset   = torchvision.datasets.ImageFolder(root='./dataset/20%/val', transform=transform)

train_loader = torch.utils.data.DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
val_loader   = torch.utils.data.DataLoader(dataset=val_dataset, batch_size=batch_size, shuffle=False)

# googlenet = torchvision.models.googlenet(weights=None, init_weights=True)
# googlenet.fc = nn.Linear(googlenet.fc.in_features, 9)

googlenet = timm.create_model('inception_v4', pretrained=False, num_classes=9)
# 选择设备
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = googlenet.to(device)

# 计算并打印模型参数量
total_params = sum(p.numel() for p in model.parameters())
trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"模型总参数量 (Total Parameters): {total_params}")
print(f"可训练参数量 (Trainable Parameters): {trainable_params}")

# 计算类权重
class_weights = compute_class_weight('balanced', classes=np.unique(train_dataset.targets), y=train_dataset.targets)
class_weights = torch.tensor(class_weights, dtype=torch.float).to(device)
# 定义损失函数和优化器
criterion = nn.CrossEntropyLoss(weight=class_weights)
optimizer = optim.Adam(model.parameters(), lr=1e-4,weight_decay=1e-5)

# 训练和验证
train_losses = []
val_losses = []
best_val_loss = float('inf')
early_stop_counter = 0

for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()  # 清空梯度
        outputs = model(images)  # 前向传播
        # 如果 outputs 是 GoogLeNetOutputs 对象, 需要提取 logits
        if isinstance(outputs, tuple):
            outputs = outputs[0]  # 只提取 logits 部分
        loss = criterion(outputs, labels)  # 计算损失
        # 检查损失是否为nan
        if torch.isnan(loss):
            print("Loss is NaN, exiting...")
            break
        loss.backward()  # 反向传播
        # 梯度裁剪，防止梯度过大
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()  # 更新梯度
        running_loss += loss.item()
    # 记录训练损失
    train_losses.append(running_loss / len(train_loader))
    # 验证模型
    model.eval()
    val_loss = 0.0
    with torch.no_grad():
        for images, labels in val_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)  # 前向传播
            # 如果 outputs 是 GoogLeNetOutputs 对象, 需要提取 logits
            if isinstance(outputs, tuple):  # 对于 GoogLeNetOutputs
                outputs = outputs[0]  # 只提取 logits 部分
            loss = criterion(outputs, labels)  # 计算损失
            val_loss += loss.item()

    # 记录验证损失
    val_losses.append(val_loss / len(val_loader))

    print(f'Epoch [{epoch + 1}/{num_epochs}], '
          f'Training Loss: {train_losses[-1]:.4f}, '
          f'Validation Loss: {val_losses[-1]:.4f}')
# Early Stopping 检查
    if val_loss < best_val_loss - min_delta:
        best_val_loss = val_loss
        early_stop_counter = 0
        # 保存当前最佳模型
        torch.save(model.state_dict(), './weight/para/goo_weights.pth')
        print(f"Validation loss improved, model saved at epoch {epoch+1}")
    else:
        early_stop_counter += 1
        print(f"No improvement in validation loss for {early_stop_counter} epochs.")

    if early_stop_counter >= patience:
        print(f"Early stopping triggered after {epoch+1} epochs!")
        break

print('Finished Training')

# 绘制损失曲线
plt.figure(figsize=(12, 6))
plt.plot(range(1, len(train_losses) + 1), train_losses, label='Training Loss', marker='o', color='skyblue')
plt.plot(range(1, len(val_losses) + 1), val_losses, label='Validation Loss', marker='o', color='lightgreen')

# 添加标题和标签
plt.title('Training and Validation Loss with Early Stopping', fontsize=16)
plt.xlabel('Epochs', fontsize=14)
plt.ylabel('Loss', fontsize=14)
plt.xticks(range(1, len(train_losses) + 1))  # 设置X轴刻度为每个epoch
plt.legend()  # 显示图例

# 显示图形
plt.grid(True)
plt.tight_layout()
plt.savefig("./show/para/T_V_Loss_with_Early_Stopping_goo.png", dpi=300, bbox_inches='tight')
plt.show(block=True)  # 阻塞直到图形窗口关闭
plt.close()  # 关闭当前图形窗口








